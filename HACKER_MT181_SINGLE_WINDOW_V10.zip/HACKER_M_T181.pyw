# HACKER M-T181 - Single Window Launcher
# Run this file with pythonw.exe/.pyw association so NO console window opens.
from app import main

if __name__ == "__main__":
    main()
