HACKER M-T181 - SINGLE WINDOW EDITION

START:
- Double-click Start.vbs OR HACKER_M_T181.pyw.
- Only the main GUI window should appear.
- No black/CMD window is intended during normal startup.

IMPORTANT:
- app.py is the main search engine.
- HACKER_M_T181.pyw is the normal GUI launcher.
- Start.vbs launches Python with pythonw hidden.
- Start.bat just launches Start.vbs.
- Debug_Start.bat is ONLY for troubleshooting and may show a console.

FILE SAFETY:
- The program scans/reads source files; it does not automatically open them
  in Excel, Word, PDF reader or any other external application.
- The selected folder is only used as a data source.
- Double-clicking a RESULT opens the software's own detail window; it does
  not open the original Excel/file.

SEARCH:
- Every worksheet/row/populated column is indexed.
- Row 1 is not skipped.
- Any matching cell returns the complete row.
- Single letter/number searches are supported.
- Search uses a fast index after initial loading.
