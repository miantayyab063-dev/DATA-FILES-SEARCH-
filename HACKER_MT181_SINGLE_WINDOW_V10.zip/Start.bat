@echo off
cd /d "%~dp0"
start "" "%~dp0Start.vbs"
exit
