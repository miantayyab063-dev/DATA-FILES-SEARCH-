Option Explicit

Dim shell, folder, pythonw, script
Set shell = CreateObject("WScript.Shell")

folder = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

pythonw = shell.ExpandEnvironmentStrings("%LocalAppData%") & "\Programs\Python\Python313\pythonw.exe"

If Not CreateObject("Scripting.FileSystemObject").FileExists(pythonw) Then
    pythonw = shell.ExpandEnvironmentStrings("%ProgramFiles%") & "\Python313\pythonw.exe"
End If

If Not CreateObject("Scripting.FileSystemObject").FileExists(pythonw) Then
    pythonw = "pythonw.exe"
End If

script = folder & "\HACKER_M_T181.pyw"

shell.CurrentDirectory = folder
shell.Run """" & pythonw & """ """ & script & """", 0, False

Set shell = Nothing
