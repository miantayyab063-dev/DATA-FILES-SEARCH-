
import os
import csv
import json
import re
import time
import sqlite3
import threading
import zipfile
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from datetime import datetime

try:
    from lxml import etree
except ImportError:
    etree = None

try:
    import openpyxl
except ImportError:
    openpyxl = None

try:
    import pandas as pd
except ImportError:
    pd = None

try:
    import xlrd
except ImportError:
    xlrd = None

try:
    import docx
except ImportError:
    docx = None

try:
    import pypdf
except ImportError:
    pypdf = None


APP_NAME = "HACKER M-T181"
DEFAULT_DATA_FOLDER = "data"
DB_NAME = "hacker_mt181_v8.db"

SUPPORTED = {
    ".xlsx",
    ".xlsm",
    ".xls",
    ".csv",
    ".docx",
    ".pdf",
    ".txt",
}

DISPLAY_LIMIT = 5000
INDEX_VERSION = "9.0-XML-BATCH-NO-FTS"
DB_BATCH = 5000


# ------------------------------------------------------------
# BASIC TEXT FUNCTIONS
# ------------------------------------------------------------
def clean(value):
    if value is None:
        return ""

    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"

    if isinstance(value, float) and value.is_integer():
        return str(int(value))

    return str(value).replace("\x00", " ").strip()


def forms(value):
    text = clean(value).casefold()
    compact = re.sub(r"[\s,._/\\()\-]+", "", text)
    return text, compact


def cell_matches(value, query):
    q, qc = forms(query)
    v, vc = forms(value)

    if not q:
        return False

    return q in v or (qc and qc in vc)


def files_under(folder):
    folder = Path(folder)

    if not folder.exists():
        return []

    return sorted(
        (
            p
            for p in folder.rglob("*")
            if p.is_file()
            and not p.name.startswith(("~$", "."))
            and p.suffix.casefold() in SUPPORTED
        ),
        key=lambda p: str(p).casefold(),
    )


# ------------------------------------------------------------
# FAST XLSX XML READER
# ------------------------------------------------------------
def col_letters(cell_ref):
    """
    Convert an Excel cell reference such as:
        A1    -> A
        L500  -> L
        AA77  -> AA

    Avoids openpyxl objects in the hot path.
    """
    letters = []

    for ch in cell_ref:
        if "A" <= ch <= "Z" or "a" <= ch <= "z":
            letters.append(ch.upper())
        else:
            break

    return "".join(letters) or "?"


def local_name(tag):
    if not isinstance(tag, str):
        return ""

    return tag.rsplit("}", 1)[-1]


def read_shared_strings(zf):
    """
    Read xl/sharedStrings.xml once.

    Rich-text <si> values are joined from all descendant text nodes.
    """
    try:
        raw = zf.open("xl/sharedStrings.xml")
    except KeyError:
        return []

    shared = []

    try:
        if etree is None:
            # Fallback for environments without lxml.
            import xml.etree.ElementTree as ET

            for event, elem in ET.iterparse(raw, events=("end",)):
                if local_name(elem.tag) == "si":
                    shared.append(
                        "".join(elem.itertext())
                    )
                    elem.clear()

            return shared

        context = etree.iterparse(
            raw,
            events=("end",),
            tag="{*}si",
            recover=True,
            huge_tree=True,
        )

        for _event, si in context:
            shared.append(
                "".join(
                    si.itertext()
                )
            )
            si.clear()

        return shared

    finally:
        raw.close()


def workbook_sheets(zf):
    """
    Returns:
        [(display_sheet_name, zip_member_path), ...]

    Uses workbook.xml + workbook.xml.rels so sheet names are accurate.
    """
    import xml.etree.ElementTree as ET

    workbook_root = ET.fromstring(
        zf.read("xl/workbook.xml")
    )

    rels = {}

    try:
        rels_root = ET.fromstring(
            zf.read("xl/_rels/workbook.xml.rels")
        )

        for rel in rels_root:
            rid = rel.attrib.get("Id")
            target = rel.attrib.get("Target", "")

            if rid:
                if target.startswith("/"):
                    target = target.lstrip("/")

                elif not target.startswith("xl/"):
                    target = "xl/" + target

                rels[rid] = target

    except Exception:
        rels = {}

    sheets = []

    for sheet in workbook_root.iter():
        if local_name(sheet.tag) != "sheet":
            continue

        name = sheet.attrib.get("name", "Sheet")
        rid = (
            sheet.attrib.get(
                "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
            )
            or sheet.attrib.get("r:id")
        )

        target = rels.get(
            rid,
            "",
        )

        if target:
            sheets.append(
                (name, target)
            )

    # Extremely defensive fallback.
    if not sheets:
        for member in sorted(
            x
            for x in zf.namelist()
            if x.startswith("xl/worksheets/")
            and x.endswith(".xml")
        ):
            sheets.append(
                (
                    Path(member).stem,
                    member,
                )
            )

    return sheets


def read_xlsx_fast(path):
    """
    HIGH-SPEED XLSX parser.

    It does not construct openpyxl Cell objects.
    It reads the underlying XML directly and yields complete rows.

    This is substantially lighter than iterating every openpyxl cell.
    """
    if etree is None:
        # If lxml is unavailable, use the old reliable fallback.
        yield from read_xlsx_openpyxl(path)
        return

    with zipfile.ZipFile(
        path,
        "r",
    ) as zf:
        shared = read_shared_strings(
            zf
        )

        sheets = workbook_sheets(
            zf
        )

        for sheet_name, member in sheets:
            with zf.open(member) as raw:
                context = etree.iterparse(
                    raw,
                    events=("end",),
                    tag="{*}row",
                    recover=True,
                    huge_tree=True,
                )

                for _event, row_elem in context:
                    row_number = int(
                        row_elem.attrib.get(
                            "r",
                            "0",
                        )
                    )

                    cells = []

                    for cell in row_elem:
                        if local_name(cell.tag) != "c":
                            continue

                        ref = cell.attrib.get(
                            "r",
                            "",
                        )

                        col = col_letters(
                            ref
                        )

                        ctype = cell.attrib.get(
                            "t",
                            "",
                        )

                        value = ""

                        if ctype == "inlineStr":
                            value = "".join(
                                cell.itertext()
                            )

                        else:
                            v_elem = None

                            for child in cell:
                                if local_name(
                                    child.tag
                                ) == "v":
                                    v_elem = child
                                    break

                            if v_elem is not None:
                                raw_value = (
                                    v_elem.text
                                    or ""
                                )

                                if ctype == "s":
                                    try:
                                        idx = int(
                                            raw_value
                                        )
                                        if 0 <= idx < len(
                                            shared
                                        ):
                                            value = shared[idx]
                                        else:
                                            value = raw_value
                                    except Exception:
                                        value = raw_value

                                elif ctype == "b":
                                    value = (
                                        "TRUE"
                                        if raw_value == "1"
                                        else "FALSE"
                                    )

                                else:
                                    value = raw_value

                            # Formula cells may have <f> without a useful
                            # cached <v>. Keep formula text searchable too.
                            if not value:
                                for child in cell:
                                    if local_name(
                                        child.tag
                                    ) == "f":
                                        value = (
                                            "="
                                            + "".join(
                                                child.itertext()
                                            )
                                        )
                                        break

                        value = clean(
                            value
                        )

                        if value:
                            cells.append(
                                (
                                    col,
                                    value,
                                )
                            )

                    if cells:
                        yield (
                            sheet_name,
                            row_number,
                            cells,
                        )

                    row_elem.clear()

                    # Keep the XML parser memory small.
                    while row_elem.getprevious() is not None:
                        del row_elem.getparent()[0]


def read_xlsx_openpyxl(path):
    """
    Reliable fallback when lxml is unavailable.
    """
    if openpyxl is None:
        raise RuntimeError(
            "openpyxl is missing."
        )

    wb = openpyxl.load_workbook(
        path,
        read_only=True,
        data_only=False,
        keep_links=False,
    )

    try:
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]

            for row_number, row in enumerate(
                ws.iter_rows(
                    values_only=True
                ),
                start=1,
            ):
                cells = []

                for col_number, value in enumerate(
                    row,
                    start=1,
                ):
                    value = clean(
                        value
                    )

                    if value:
                        cells.append(
                            (
                                openpyxl.utils.get_column_letter(
                                    col_number
                                ),
                                value,
                            )
                        )

                if cells:
                    yield (
                        sheet_name,
                        row_number,
                        cells,
                    )
    finally:
        wb.close()


# ------------------------------------------------------------
# OTHER FILE READERS
# ------------------------------------------------------------
def read_xls(path):
    if pd is None or xlrd is None:
        raise RuntimeError(
            "Install pandas + xlrd for .xls files."
        )

    book = pd.ExcelFile(
        path,
        engine="xlrd",
    )

    try:
        for sheet_name in book.sheet_names:
            df = pd.read_excel(
                book,
                sheet_name=sheet_name,
                header=None,
                dtype=str,
            ).fillna("")

            for row_number, row in enumerate(
                df.itertuples(
                    index=False,
                    name=None,
                ),
                start=1,
            ):
                cells = []

                for col_number, value in enumerate(
                    row,
                    start=1,
                ):
                    value = clean(
                        value
                    )

                    if value:
                        col = (
                            openpyxl.utils.get_column_letter(
                                col_number
                            )
                            if openpyxl
                            else f"Col_{col_number}"
                        )

                        cells.append(
                            (
                                col,
                                value,
                            )
                        )

                if cells:
                    yield (
                        sheet_name,
                        row_number,
                        cells,
                    )
    finally:
        book.close()


def read_csv(path):
    with open(
        path,
        "r",
        encoding="utf-8-sig",
        errors="replace",
        newline="",
    ) as f:
        reader = csv.reader(
            f
        )

        for row_number, row in enumerate(
            reader,
            start=1,
        ):
            cells = []

            for col_number, value in enumerate(
                row,
                start=1,
            ):
                value = clean(
                    value
                )

                if value:
                    col = (
                        openpyxl.utils.get_column_letter(
                            col_number
                        )
                        if openpyxl
                        else f"Col_{col_number}"
                    )

                    cells.append(
                        (
                            col,
                            value,
                        )
                    )

            if cells:
                yield (
                    "CSV",
                    row_number,
                    cells,
                )


def read_docx(path):
    if docx is None:
        raise RuntimeError(
            "python-docx is missing."
        )

    document = docx.Document(
        path
    )

    for n, paragraph in enumerate(
        document.paragraphs,
        start=1,
    ):
        value = clean(
            paragraph.text
        )

        if value:
            yield (
                "Paragraph",
                n,
                [
                    (
                        "Text",
                        value,
                    )
                ],
            )

    for table_no, table in enumerate(
        document.tables,
        start=1,
    ):
        for row_no, row in enumerate(
            table.rows,
            start=1,
        ):
            cells = []

            for col_no, cell in enumerate(
                row.cells,
                start=1,
            ):
                value = clean(
                    cell.text
                )

                if value:
                    cells.append(
                        (
                            f"Col_{col_no}",
                            value,
                        )
                    )

            if cells:
                yield (
                    f"Table {table_no}",
                    row_no,
                    cells,
                )


def read_pdf(path):
    if pypdf is None:
        raise RuntimeError(
            "pypdf is missing."
        )

    reader = pypdf.PdfReader(
        path
    )

    for page_no, page in enumerate(
        reader.pages,
        start=1,
    ):
        text = page.extract_text() or ""

        for line_no, line in enumerate(
            text.splitlines(),
            start=1,
        ):
            value = clean(
                line
            )

            if value:
                yield (
                    f"Page {page_no}",
                    line_no,
                    [
                        (
                            "Text",
                            value,
                        )
                    ],
                )


def read_txt(path):
    with open(
        path,
        "r",
        encoding="utf-8",
        errors="replace",
    ) as f:
        for line_no, line in enumerate(
            f,
            start=1,
        ):
            value = clean(
                line
            )

            if value:
                yield (
                    "TXT",
                    line_no,
                    [
                        (
                            "Text",
                            value,
                        )
                    ],
                )


def read_rows(path):
    ext = path.suffix.casefold()

    if ext in {
        ".xlsx",
        ".xlsm",
    }:
        yield from read_xlsx_fast(
            path
        )

    elif ext == ".xls":
        yield from read_xls(
            path
        )

    elif ext == ".csv":
        yield from read_csv(
            path
        )

    elif ext == ".docx":
        yield from read_docx(
            path
        )

    elif ext == ".pdf":
        yield from read_pdf(
            path
        )

    elif ext == ".txt":
        yield from read_txt(
            path
        )


def full_row_text(cells):
    return " | ".join(
        f"[{col}]: {value}"
        for col, value in cells
    )


def search_text(cells):
    """One searchable string per row. No trigram/FTS index is built."""
    normal_parts = []
    compact_parts = []

    for _, value in cells:
        if value:
            text, compact = forms(value)
            if text:
                normal_parts.append(text)
            if compact:
                compact_parts.append(compact)

    return " ".join(normal_parts) + " " + " ".join(compact_parts)


def chars_for_row(cells):
    text = "".join(
        forms(value)[1]
        for _, value in cells
        if value
    )

    return {
        char
        for char in text
        if char.isalnum()
    }


# ------------------------------------------------------------
# DATABASE INDEX
# ------------------------------------------------------------
class FastIndex:
    """Fast disposable SQLite index optimized for very large Excel files.

    V9 deliberately removes SQLite FTS5/trigram indexing. FTS5 is excellent for
    repeated substring queries, but for this application it adds a large amount
    of write/index-build work. Instead we keep one compact lowercase search_blob
    per row and use SQLite's native INSTR() scan. The scan is performed in C and
    avoids Python row-by-row comparisons until matching rows are found.

    Important:
      * Row 1 is searchable.
      * All sheets and subfolders are included.
      * Source files are read only.
      * The database can always be rebuilt because it is only a cache/index.
    """

    def __init__(self, db_path):
        self.db_path = str(db_path)
        self.lock = threading.RLock()

        self.conn = sqlite3.connect(
            self.db_path,
            check_same_thread=False,
            timeout=180,
        )
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA temp_store=MEMORY")
        self.conn.execute("PRAGMA cache_size=-100000")
        self.conn.execute("PRAGMA mmap_size=1073741824")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.setup()

    def setup(self):
        with self.lock:
            c = self.conn.cursor()
            c.execute("""
                CREATE TABLE IF NOT EXISTS meta(
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            """)
            c.execute("""
                CREATE TABLE IF NOT EXISTS files(
                    id INTEGER PRIMARY KEY,
                    path TEXT UNIQUE NOT NULL,
                    mtime_ns INTEGER NOT NULL,
                    file_size INTEGER NOT NULL,
                    row_count INTEGER NOT NULL DEFAULT 0,
                    indexed_ok INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT DEFAULT ''
                )
            """)
            c.execute("""
                CREATE TABLE IF NOT EXISTS rows(
                    id INTEGER PRIMARY KEY,
                    file_id INTEGER NOT NULL,
                    sheet_name TEXT NOT NULL,
                    row_number INTEGER NOT NULL,
                    search_blob TEXT NOT NULL,
                    cells_json TEXT NOT NULL,
                    FOREIGN KEY(file_id) REFERENCES files(id) ON DELETE CASCADE
                )
            """)
            c.execute("CREATE INDEX IF NOT EXISTS idx_files_ok ON files(indexed_ok)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_rows_file ON rows(file_id)")

            c.execute("SELECT value FROM meta WHERE key='version'")
            current = c.fetchone()
            if not current or current[0] != INDEX_VERSION:
                # Index is disposable. Rebuild cleanly when the format changes.
                try:
                    c.execute("DROP TABLE IF EXISTS rows")
                    c.execute("DROP TABLE IF EXISTS files")
                    c.execute("DROP TABLE IF EXISTS meta")
                    c.execute("CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT)")
                    c.execute("""
                        CREATE TABLE files(
                            id INTEGER PRIMARY KEY,
                            path TEXT UNIQUE NOT NULL,
                            mtime_ns INTEGER NOT NULL,
                            file_size INTEGER NOT NULL,
                            row_count INTEGER NOT NULL DEFAULT 0,
                            indexed_ok INTEGER NOT NULL DEFAULT 0,
                            last_error TEXT DEFAULT ''
                        )
                    """)
                    c.execute("""
                        CREATE TABLE rows(
                            id INTEGER PRIMARY KEY,
                            file_id INTEGER NOT NULL,
                            sheet_name TEXT NOT NULL,
                            row_number INTEGER NOT NULL,
                            search_blob TEXT NOT NULL,
                            cells_json TEXT NOT NULL,
                            FOREIGN KEY(file_id) REFERENCES files(id) ON DELETE CASCADE
                        )
                    """)
                    c.execute("CREATE INDEX idx_files_ok ON files(indexed_ok)")
                    c.execute("CREATE INDEX idx_rows_file ON rows(file_id)")
                    c.execute(
                        "INSERT INTO meta(key,value) VALUES('version',?)",
                        (INDEX_VERSION,),
                    )
                except Exception:
                    self.conn.rollback()
                    raise
            self.conn.commit()

    def close(self):
        with self.lock:
            try:
                self.conn.close()
            except Exception:
                pass

    def stats(self):
        with self.lock:
            c = self.conn.cursor()
            c.execute("SELECT COUNT(*) FROM files WHERE indexed_ok=1")
            good = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM files")
            total = c.fetchone()[0]
            c.execute("SELECT COALESCE(SUM(row_count),0) FROM files WHERE indexed_ok=1")
            rows = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM files WHERE indexed_ok=0")
            failed = c.fetchone()[0]
            return good, total, rows, failed

    def delete_file(self, file_id):
        with self.lock:
            c = self.conn.cursor()
            c.execute("DELETE FROM rows WHERE file_id=?", (file_id,))
            c.execute("DELETE FROM files WHERE id=?", (file_id,))
            self.conn.commit()

    def scan(self, folder, progress=None, cancel=None):
        files = files_under(folder)
        total_files = len(files)

        disk_paths = {str(p.resolve()) for p in files}
        with self.lock:
            c = self.conn.cursor()
            c.execute("SELECT path,id FROM files")
            db_paths = {p: fid for p, fid in c.fetchall()}

        for old_path in (set(db_paths) - disk_paths):
            self.delete_file(db_paths[old_path])

        errors = []
        started = time.perf_counter()

        for file_no, path in enumerate(files, start=1):
            if cancel and cancel.is_set():
                break

            path_str = str(path.resolve())
            try:
                st = path.stat()
                sig = (st.st_mtime_ns, st.st_size)
            except Exception as exc:
                errors.append(f"{path.name}: {exc}")
                if progress:
                    progress("error", file_no, total_files, path, 0)
                continue

            with self.lock:
                c = self.conn.cursor()
                c.execute(
                    "SELECT id,mtime_ns,file_size,indexed_ok,row_count FROM files WHERE path=?",
                    (path_str,),
                )
                cached = c.fetchone()

            if cached and cached[3] == 1 and (cached[1], cached[2]) == sig:
                if progress:
                    progress("cached", file_no, total_files, path, cached[4])
                continue

            if progress:
                progress("start", file_no, total_files, path, 0)

            file_id = cached[0] if cached else None
            row_count = 0

            try:
                with self.lock:
                    c = self.conn.cursor()
                    c.execute("BEGIN IMMEDIATE")

                    if file_id is not None:
                        c.execute("DELETE FROM rows WHERE file_id=?", (file_id,))
                        c.execute(
                            "UPDATE files SET mtime_ns=?,file_size=?,row_count=0,indexed_ok=2,last_error='' WHERE id=?",
                            (st.st_mtime_ns, st.st_size, file_id),
                        )
                    else:
                        c.execute(
                            "INSERT INTO files(path,mtime_ns,file_size,row_count,indexed_ok,last_error) VALUES(?,?,?,?,2,'')",
                            (path_str, st.st_mtime_ns, st.st_size, 0),
                        )
                        file_id = c.lastrowid

                    c.execute("SELECT COALESCE(MAX(id),0) FROM rows")
                    next_row_id = c.fetchone()[0] + 1

                rows_batch = []
                last_progress = time.perf_counter()

                for sheet_name, row_number, cells in read_rows(path):
                    if cancel and cancel.is_set():
                        raise RuntimeError("Scan cancelled.")

                    rid = next_row_id
                    next_row_id += 1
                    row_count += 1

                    # Only two persisted copies are kept for speed:
                    # searchable text + the exact cells needed for display.
                    blob = search_text(cells)
                    cells_json = json.dumps(cells, ensure_ascii=False, separators=(",", ":"))
                    rows_batch.append(
                        (rid, file_id, sheet_name, row_number, blob, cells_json)
                    )

                    if len(rows_batch) >= 10000:
                        with self.lock:
                            c = self.conn.cursor()
                            c.executemany(
                                """
                                INSERT INTO rows
                                (id,file_id,sheet_name,row_number,search_blob,cells_json)
                                VALUES(?,?,?,?,?,?)
                                """,
                                rows_batch,
                            )
                            # Commit each large batch so LIVE SEARCH can see
                            # rows as soon as they are loaded, instead of
                            # waiting for the entire large Excel file.
                            self.conn.commit()
                            self.conn.execute("BEGIN IMMEDIATE")
                        rows_batch.clear()

                    now = time.perf_counter()
                    if progress and (now - last_progress >= 0.5):
                        progress("reading", file_no, total_files, path, row_count)
                        last_progress = now

                if rows_batch:
                    with self.lock:
                        c = self.conn.cursor()
                        c.executemany(
                            """
                            INSERT INTO rows
                            (id,file_id,sheet_name,row_number,search_blob,cells_json)
                            VALUES(?,?,?,?,?,?)
                            """,
                            rows_batch,
                        )

                with self.lock:
                    c = self.conn.cursor()
                    c.execute(
                        "UPDATE files SET row_count=?,indexed_ok=1,last_error='' WHERE id=?",
                        (row_count, file_id),
                    )
                    self.conn.commit()

                if progress:
                    elapsed = time.perf_counter() - started
                    progress("done", file_no, total_files, path, row_count)

            except Exception as exc:
                error_text = str(exc)
                with self.lock:
                    try:
                        self.conn.rollback()
                    except Exception:
                        pass
                    c = self.conn.cursor()
                    if file_id is not None:
                        c.execute(
                            "DELETE FROM rows WHERE file_id=?",
                            (file_id,),
                        )
                        c.execute(
                            "UPDATE files SET indexed_ok=0,row_count=0,last_error=? WHERE id=?",
                            (error_text, file_id),
                        )
                    self.conn.commit()

                errors.append(f"{path.name}: {error_text}")
                if progress:
                    progress("error", file_no, total_files, path, 0)

        good, total, rows, failed = self.stats()
        return {
            "ok_files": good,
            "files": total,
            "rows": rows,
            "failed": failed,
            "errors": errors,
        }

    def search(self, query):
        q, qc = forms(query)
        if not q:
            return []

        # INSTR is a compiled SQLite string operation. This avoids pulling all
        # rows into Python just to test the query and avoids the heavy trigram
        # index that made large-file indexing slow.
        # indexed_ok=2 means the file is currently scanning but its already-
        # inserted rows are immediately eligible for LIVE SEARCH.
        with self.lock:
            c = self.conn.cursor()
            c.execute(
                """
                SELECT rows.id, files.path, rows.sheet_name, rows.row_number, rows.cells_json
                FROM rows
                JOIN files ON files.id=rows.file_id
                WHERE files.indexed_ok IN (1,2)
                  AND (instr(rows.search_blob, ?) > 0 OR instr(rows.search_blob, ?) > 0)
                LIMIT ?
                """,
                (q, qc or q, DISPLAY_LIMIT),
            )
            fetched = c.fetchall()

        results = []
        for rid, path, sheet_name, row_number, cells_json in fetched:
            cells = json.loads(cells_json)
            matched = [
                (col, value)
                for col, value in cells
                if cell_matches(value, query)
            ]
            if matched:
                results.append({
                    "id": rid,
                    "path": path,
                    "sheet": sheet_name,
                    "row": row_number,
                    "cells": cells,
                    "matched": matched,
                    "full": full_row_text(cells),
                })
        return results


# ------------------------------------------------------------
# GUI
# ------------------------------------------------------------
class App:
    def __init__(self, root):
        self.root = root

        self.root.title(
            f"{APP_NAME} | FAST V10 LIVE SEARCH"
        )
        self.root.geometry(
            "1580x900"
        )
        self.root.minsize(
            1150,
            650,
        )
        self.root.configure(
            bg="#080d16"
        )

        self.base_dir = Path(
            os.path.dirname(
                os.path.abspath(__file__)
            )
            if "__file__" in globals()
            else os.getcwd()
        )

        self.folder = (
            self.base_dir
            / DEFAULT_DATA_FOLDER
        )

        self.folder.mkdir(
            parents=True,
            exist_ok=True,
        )

        self.db_path = (
            self.base_dir
            / DB_NAME
        )

        self.index = FastIndex(
            self.db_path
        )

        self.scanning = False
        self.cancel_scan = threading.Event()

        self.search_after = None
        self.search_token = 0

        self.current_query = ""
        self.current_results = []

        self.setup_styles()
        self.setup_ui()
        self.refresh_file_panel()

        self.root.after(
            250,
            self.start_scan,
        )

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure(
            "Treeview",
            background="#111827",
            foreground="#e5e7eb",
            fieldbackground="#111827",
            rowheight=29,
            font=("Segoe UI", 9),
        )

        style.map(
            "Treeview",
            background=[
                ("selected", "#075985")
            ],
            foreground=[
                ("selected", "#ffffff")
            ],
        )

        style.configure(
            "Treeview.Heading",
            background="#1f2937",
            foreground="#22d3ee",
            font=("Segoe UI", 9, "bold"),
        )

        style.configure(
            "Fast.Horizontal.TProgressbar",
            background="#22d3ee",
            troughcolor="#1f2937",
        )

    def setup_ui(self):
        header = tk.Frame(
            self.root,
            bg="#0f172a",
            padx=16,
            pady=11,
        )
        header.pack(
            fill="x"
        )

        tk.Label(
            header,
            text=f"⚡ {APP_NAME}",
            font=("Segoe UI", 17, "bold"),
            fg="#22d3ee",
            bg="#0f172a",
        ).pack(
            side="left"
        )

        tk.Label(
            header,
            text=" | FAST XML + LIVE SEARCH",
            font=("Segoe UI", 10, "bold"),
            fg="#94a3b8",
            bg="#0f172a",
        ).pack(
            side="left",
            padx=7,
        )

        self.lbl_stats = tk.Label(
            header,
            text="Starting...",
            font=("Segoe UI", 10, "bold"),
            fg="#34d399",
            bg="#0f172a",
        )
        self.lbl_stats.pack(
            side="right"
        )

        controls = tk.Frame(
            self.root,
            bg="#1e293b",
            padx=14,
            pady=11,
            bd=1,
            relief="solid",
        )
        controls.pack(
            fill="x",
            padx=12,
            pady=(8, 5),
        )

        tk.Label(
            controls,
            text="SEARCH:",
            font=("Segoe UI", 11, "bold"),
            fg="#22d3ee",
            bg="#1e293b",
        ).pack(
            side="left",
            padx=(0, 7),
        )

        self.entry = tk.Entry(
            controls,
            font=("Segoe UI", 13),
            width=46,
            bg="#0b1220",
            fg="#ffffff",
            insertbackground="#22d3ee",
            relief="flat",
            bd=2,
        )
        self.entry.pack(
            side="left",
            padx=5,
            ipady=5,
        )

        self.entry.bind(
            "<KeyRelease>",
            self.on_typing,
        )

        self.entry.bind(
            "<Return>",
            lambda _e: self.start_search(),
        )

        tk.Button(
            controls,
            text="🔎 Search",
            font=("Segoe UI", 9, "bold"),
            bg="#0284c7",
            fg="#ffffff",
            padx=14,
            pady=5,
            relief="flat",
            command=self.start_search,
        ).pack(
            side="left",
            padx=4,
        )

        tk.Button(
            controls,
            text="✖ Clear",
            font=("Segoe UI", 9, "bold"),
            bg="#475569",
            fg="#ffffff",
            padx=11,
            pady=5,
            relief="flat",
            command=self.clear_search,
        ).pack(
            side="left",
            padx=4,
        )

        tk.Button(
            controls,
            text="📂 Select Data Folder",
            font=("Segoe UI", 9, "bold"),
            bg="#0f766e",
            fg="#ffffff",
            padx=12,
            pady=5,
            relief="flat",
            command=self.choose_folder,
        ).pack(
            side="left",
            padx=4,
        )

        tk.Button(
            controls,
            text="🔄 Rescan",
            font=("Segoe UI", 9, "bold"),
            bg="#10b981",
            fg="#ffffff",
            padx=12,
            pady=5,
            relief="flat",
            command=self.start_scan,
        ).pack(
            side="right",
            padx=4,
        )

        tk.Button(
            controls,
            text="📄 Export ALL",
            font=("Segoe UI", 9, "bold"),
            bg="#e11d48",
            fg="#ffffff",
            padx=13,
            pady=5,
            relief="flat",
            command=self.export_all,
        ).pack(
            side="right",
            padx=4,
        )

        info = tk.Frame(
            self.root,
            bg="#111827",
            padx=12,
            pady=8,
        )
        info.pack(
            fill="x",
            padx=12,
            pady=(0, 5),
        )

        self.lbl_status = tk.Label(
            info,
            text="Loading...",
            font=("Segoe UI", 9),
            fg="#cbd5e1",
            bg="#111827",
            anchor="w",
        )
        self.lbl_status.pack(
            fill="x"
        )

        self.lbl_folder = tk.Label(
            info,
            text=f"DATA FOLDER: {self.folder}",
            font=("Segoe UI", 8),
            fg="#64748b",
            bg="#111827",
            anchor="w",
        )
        self.lbl_folder.pack(
            fill="x",
            pady=(3, 0),
        )

        self.progress = ttk.Progressbar(
            info,
            style="Fast.Horizontal.TProgressbar",
            mode="indeterminate",
        )
        self.progress.pack(
            fill="x",
            pady=(7, 0),
        )

        body = tk.Frame(
            self.root,
            bg="#080d16",
        )
        body.pack(
            fill="both",
            expand=True,
            padx=12,
            pady=(0, 12),
        )

        results = tk.Frame(
            body,
            bg="#111827",
            bd=1,
            relief="solid",
        )
        results.pack(
            side="left",
            fill="both",
            expand=True,
        )

        rh = tk.Frame(
            results,
            bg="#1f2937",
            padx=10,
            pady=7,
        )
        rh.pack(fill="x")

        self.lbl_results = tk.Label(
            rh,
            text="📋 MATCHING ROWS",
            font=("Segoe UI", 10, "bold"),
            fg="#f8fafc",
            bg="#1f2937",
        )
        self.lbl_results.pack(
            side="left"
        )

        tk.Label(
            rh,
            text="Double-click = complete row + all columns",
            font=("Segoe UI", 8),
            fg="#94a3b8",
            bg="#1f2937",
        ).pack(
            side="right"
        )

        tf = tk.Frame(
            results,
            bg="#111827",
        )
        tf.pack(
            fill="both",
            expand=True,
        )

        sy = ttk.Scrollbar(
            tf,
            orient="vertical",
        )
        sx = ttk.Scrollbar(
            tf,
            orient="horizontal",
        )

        self.tree = ttk.Treeview(
            tf,
            columns=(
                "file",
                "type",
                "location",
                "matched",
                "complete",
            ),
            show="headings",
            yscrollcommand=sy.set,
            xscrollcommand=sx.set,
        )

        sy.config(
            command=self.tree.yview
        )
        sx.config(
            command=self.tree.xview
        )

        sy.pack(
            side="right",
            fill="y",
        )
        sx.pack(
            side="bottom",
            fill="x",
        )
        self.tree.pack(
            fill="both",
            expand=True,
        )

        for cid, title, width in [
            ("file", "FILE", 240),
            ("type", "TYPE", 70),
            ("location", "SHEET / ROW", 220),
            ("matched", "🎯 MATCHED CELL(S)", 380),
            ("complete", "COMPLETE ROW — ALL COLUMNS", 900),
        ]:
            self.tree.heading(
                cid,
                text=title,
            )
            self.tree.column(
                cid,
                width=width,
                anchor="w",
            )

        self.tree.bind(
            "<Double-1>",
            self.show_detail,
        )

        files_panel = tk.Frame(
            body,
            bg="#111827",
            width=320,
            bd=1,
            relief="solid",
        )
        files_panel.pack(
            side="right",
            fill="y",
            padx=(8, 0),
        )
        files_panel.pack_propagate(
            False
        )

        fh = tk.Frame(
            files_panel,
            bg="#1f2937",
            padx=10,
            pady=7,
        )
        fh.pack(
            fill="x"
        )

        tk.Label(
            fh,
            text="📁 SELECTED FOLDER FILES",
            font=("Segoe UI", 9, "bold"),
            fg="#22d3ee",
            bg="#1f2937",
        ).pack(
            side="left"
        )

        self.lbl_file_count = tk.Label(
            fh,
            text="0",
            font=("Segoe UI", 9, "bold"),
            fg="#34d399",
            bg="#1f2937",
        )
        self.lbl_file_count.pack(
            side="right"
        )

        ff = tk.Frame(
            files_panel,
            bg="#111827",
        )
        ff.pack(
            fill="both",
            expand=True,
        )

        fsy = ttk.Scrollbar(
            ff,
            orient="vertical",
        )

        self.file_tree = ttk.Treeview(
            ff,
            columns=(
                "name",
                "size",
            ),
            show="headings",
            yscrollcommand=fsy.set,
        )

        fsy.config(
            command=self.file_tree.yview
        )

        fsy.pack(
            side="right",
            fill="y",
        )

        self.file_tree.pack(
            fill="both",
            expand=True,
        )

        self.file_tree.heading(
            "name",
            text="FILE"
        )
        self.file_tree.heading(
            "size",
            text="SIZE"
        )

        self.file_tree.column(
            "name",
            width=225,
            anchor="w",
        )
        self.file_tree.column(
            "size",
            width=75,
            anchor="center",
        )

    # ---------------------------------------------------------
    # FOLDER
    # ---------------------------------------------------------
    def choose_folder(self):
        selected = filedialog.askdirectory(
            initialdir=str(
                self.folder
            ),
            title=(
                "Select the folder containing your data files"
            ),
        )

        if not selected:
            return

        self.folder = Path(
            selected
        )

        self.lbl_folder.config(
            text=f"DATA FOLDER: {self.folder}"
        )

        self.current_query = ""
        self.current_results = []

        self.clear_results()

        self.refresh_file_panel()

        safe_name = re.sub(
            r"[^A-Za-z0-9]+",
            "_",
            self.folder.name,
        ).strip("_") or "folder"

        try:
            self.index.close()
        except Exception:
            pass

        self.index = FastIndex(
            self.base_dir
            / f"hacker_mt181_{safe_name}_v7.db"
        )

        self.start_scan()

    def refresh_file_panel(self):
        for item in self.file_tree.get_children():
            self.file_tree.delete(item)

        files = files_under(
            self.folder
        )

        for p in files:
            try:
                n = p.stat().st_size

                text = (
                    f"{n/1024/1024:.1f} MB"
                    if n >= 1024 * 1024
                    else f"{n/1024:.0f} KB"
                )
            except Exception:
                text = "-"

            try:
                display = str(
                    p.relative_to(
                        self.folder
                    )
                )
            except Exception:
                display = p.name

            self.file_tree.insert(
                "",
                "end",
                values=(
                    display,
                    text,
                ),
            )

        self.lbl_file_count.config(
            text=f"{len(files):,}"
        )

    # ---------------------------------------------------------
    # SCAN
    # ---------------------------------------------------------
    def start_scan(self):
        if self.scanning:
            return

        self.refresh_file_panel()

        self.scanning = True
        self.cancel_scan.clear()

        self.progress["mode"] = "indeterminate"
        self.progress.start(10)

        self.lbl_status.config(
            text=(
                "🚀 FAST SCAN + LIVE SEARCH: loaded rows are searchable immediately."
            ),
            fg="#22d3ee",
        )

        self.lbl_stats.config(
            text="Scanning...",
            fg="#38bdf8",
        )

        threading.Thread(
            target=self.scan_worker,
            daemon=True,
        ).start()

    def scan_worker(self):
        started = time.perf_counter()

        result = self.index.scan(
            self.folder,
            progress=self.scan_callback,
            cancel=self.cancel_scan,
        )

        elapsed = (
            time.perf_counter()
            - started
        )

        self.root.after(
            0,
            self.scan_done,
            result,
            elapsed,
        )

    def scan_callback(
        self,
        kind,
        number,
        total,
        path,
        rows,
    ):
        self.root.after(
            0,
            self.scan_ui,
            kind,
            number,
            total,
            str(path),
            rows,
        )

    def scan_ui(
        self,
        kind,
        number,
        total,
        path,
        rows,
    ):
        name = Path(
            path
        ).name

        if kind == "start":
            message = (
                f"📖 [{number}/{total}] "
                f"Reading {name}..."
            )

        elif kind == "reading":
            message = (
                f"⚡ [{number}/{total}] "
                f"{name} | {rows:,} rows loaded"
            )

        elif kind == "done":
            message = (
                f"✅ [{number}/{total}] "
                f"{name} | {rows:,} rows indexed"
            )

        elif kind == "cached":
            message = (
                f"⚡ [{number}/{total}] "
                f"{name} | reused {rows:,} rows"
            )

        else:
            message = (
                f"⚠ [{number}/{total}] "
                f"{name} failed"
            )

        self.lbl_status.config(
            text=message,
            fg=(
                "#fbbf24"
                if kind == "error"
                else "#22d3ee"
            ),
        )

        self.lbl_stats.config(
            text=(
                f"FILE {number}/{total} | "
                f"CURRENT ROWS {rows:,}"
            ),
            fg="#38bdf8",
        )

    def scan_done(
        self,
        result,
        elapsed,
    ):
        self.scanning = False

        self.progress.stop()
        self.progress["mode"] = "determinate"
        self.progress["value"] = 100

        self.refresh_file_panel()

        self.lbl_stats.config(
            text=(
                f"READY | {result['ok_files']:,}/"
                f"{result['files']:,} FILES | "
                f"{result['rows']:,} ROWS | "
                f"{elapsed:.1f}s"
            ),
            fg="#34d399"
            if not result["failed"]
            else "#fbbf24",
        )

        text = (
            f"✅ Scan complete in {elapsed:.1f}s — "
            f"{result['ok_files']:,} files / "
            f"{result['rows']:,} rows indexed."
        )

        if result["failed"]:
            text += (
                f" ⚠ {result['failed']} file(s) failed."
            )

        self.lbl_status.config(
            text=text,
            fg="#34d399"
            if not result["failed"]
            else "#fbbf24",
        )

        if self.current_query:
            self.start_search()

    # ---------------------------------------------------------
    # SEARCH
    # ---------------------------------------------------------
    def on_typing(self, event=None):
        if event and event.keysym in {
            "Up",
            "Down",
            "Left",
            "Right",
            "Shift_L",
            "Shift_R",
            "Control_L",
            "Control_R",
            "Alt_L",
            "Alt_R",
            "Caps_Lock",
        }:
            return

        if self.search_after:
            try:
                self.root.after_cancel(
                    self.search_after
                )
            except Exception:
                pass

        self.search_after = self.root.after(
            200,
            self.start_search,
        )

    def start_search(self):
        query = self.entry.get().strip()

        if not query:
            self.clear_search()
            return

        # LIVE SEARCH: even while the folder is still scanning, search the
        # rows already loaded/indexed so far. When the scan finishes,
        # scan_done() automatically runs the same search again for the final
        # complete dataset.
        self.search_token += 1
        token = self.search_token

        self.current_query = query

        self.clear_results()

        started = time.perf_counter()

        if self.scanning:
            self.lbl_status.config(
                text=(
                    f"🔎 LIVE SEARCH: '{query}' — searching rows loaded so far. "
                    "Final full search will run automatically when scanning completes."
                ),
                fg="#fbbf24",
            )

        threading.Thread(
            target=self.search_worker,
            args=(
                query,
                token,
                started,
            ),
            daemon=True,
        ).start()

    def search_worker(
        self,
        query,
        token,
        started,
    ):
        results = self.index.search(
            query
        )

        elapsed = (
            time.perf_counter()
            - started
        )

        self.root.after(
            0,
            self.search_done,
            query,
            token,
            results,
            elapsed,
        )

    def search_done(
        self,
        query,
        token,
        results,
        elapsed,
    ):
        if token != self.search_token:
            return

        self.current_results = results

        total = len(
            results
        )

        shown = min(
            total,
            DISPLAY_LIMIT,
        )

        for result in results[:shown]:
            path = Path(
                result["path"]
            )

            matched = " | ".join(
                f"[{c}]: {v}"
                for c, v
                in result["matched"]
            )

            self.tree.insert(
                "",
                "end",
                values=(
                    path.name,
                    path.suffix.replace(
                        ".",
                        "",
                    ).upper(),
                    (
                        f"Sheet: {result['sheet']} | "
                        f"Row: {result['row']}"
                    ),
                    matched,
                    result["full"],
                ),
            )

        if total:
            suffix = (
                f" | Showing {shown:,}"
                if total > shown
                else ""
            )

            self.lbl_results.config(
                text=(
                    f"📋 {total:,} MATCHES | "
                    f"'{query}'"
                ),
            )

            if self.scanning:
                status = (
                    f"⚡ LIVE SEARCH {elapsed*1000:.1f} ms | "
                    f"{total:,} matches in rows loaded so far. "
                    "Full final result will refresh automatically after scan."
                )
                color = "#fbbf24"
            else:
                status = (
                    f"✅ FINAL SEARCH {elapsed*1000:.1f} ms | "
                    f"ANY cell match → COMPLETE row."
                )
                color = "#34d399"

            self.lbl_status.config(
                text=status + suffix,
                fg=color,
            )

        else:
            self.lbl_results.config(
                text=(
                    f"📋 0 MATCHES | "
                    f"'{query}'"
                ),
            )

            if self.scanning:
                status = (
                    f"🔎 LIVE SEARCH: '{query}' not found in rows loaded so far. "
                    "The full folder will be checked again automatically after scan."
                )
                color = "#fbbf24"
            else:
                status = f"❌ FINAL: '{query}' not found anywhere in the indexed files."
                color = "#f87171"

            self.lbl_status.config(
                text=status,
                fg=color,
            )

    def clear_results(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

    def clear_search(self):
        self.search_token += 1

        self.current_query = ""
        self.current_results = []

        self.entry.delete(
            0,
            "end",
        )

        self.clear_results()

        self.lbl_results.config(
            text="📋 MATCHING ROWS"
        )

        self.lbl_status.config(
            text="Search cleared.",
            fg="#94a3b8",
        )

        self.entry.focus_set()

    # ---------------------------------------------------------
    # DETAIL
    # ---------------------------------------------------------
    def show_detail(self, _event=None):
        selected = self.tree.selection()

        if not selected:
            return

        idx = self.tree.index(
            selected[0]
        )

        if idx >= len(
            self.current_results
        ):
            return

        r = self.current_results[
            idx
        ]

        win = tk.Toplevel(
            self.root
        )
        win.title(
            "Complete Row | HACKER M-T181"
        )
        win.geometry(
            "1080x730"
        )
        win.configure(
            bg="#0b0f19"
        )

        tk.Label(
            win,
            text=(
                f"📄 {Path(r['path']).name}"
            ),
            font=("Segoe UI", 13, "bold"),
            fg="#22d3ee",
            bg="#0b0f19",
            pady=10,
        ).pack(
            fill="x"
        )

        tk.Label(
            win,
            text=(
                f"📍 Sheet: {r['sheet']} | "
                f"Row: {r['row']}"
            ),
            font=("Segoe UI", 10, "bold"),
            fg="#34d399",
            bg="#0b0f19",
        ).pack(
            anchor="w",
            padx=15,
        )

        tk.Label(
            win,
            text=(
                "🎯 MATCHED CELL(S): "
                + " | ".join(
                    f"[{c}]: {v}"
                    for c, v
                    in r["matched"]
                )
            ),
            font=("Segoe UI", 10, "bold"),
            fg="#fbbf24",
            bg="#0b0f19",
            wraplength=1000,
            justify="left",
        ).pack(
            anchor="w",
            padx=15,
            pady=7,
        )

        frame = tk.Frame(
            win,
            bg="#111827",
        )
        frame.pack(
            fill="both",
            expand=True,
            padx=15,
            pady=10,
        )

        sy = ttk.Scrollbar(
            frame,
            orient="vertical",
        )
        sx = ttk.Scrollbar(
            frame,
            orient="horizontal",
        )

        tv = ttk.Treeview(
            frame,
            columns=(
                "column",
                "value",
                "matched",
            ),
            show="headings",
            yscrollcommand=sy.set,
            xscrollcommand=sx.set,
        )

        sy.config(
            command=tv.yview
        )
        sx.config(
            command=tv.xview
        )

        sy.pack(
            side="right",
            fill="y",
        )
        sx.pack(
            side="bottom",
            fill="x",
        )
        tv.pack(
            fill="both",
            expand=True,
        )

        tv.heading(
            "column",
            text="COLUMN"
        )
        tv.heading(
            "value",
            text="CELL VALUE"
        )
        tv.heading(
            "matched",
            text="MATCH"
        )

        tv.column(
            "column",
            width=100,
            anchor="center",
        )
        tv.column(
            "value",
            width=820,
            anchor="w",
        )
        tv.column(
            "matched",
            width=80,
            anchor="center",
        )

        matched_cols = {
            c
            for c, _
            in r["matched"]
        }

        for col, value in r["cells"]:
            tv.insert(
                "",
                "end",
                values=(
                    col,
                    value,
                    "YES"
                    if col in matched_cols
                    else "",
                ),
            )

    # ---------------------------------------------------------
    # EXPORT
    # ---------------------------------------------------------
    def export_all(self):
        if not self.current_query:
            messagebox.showwarning(
                "No Search",
                "Pehle search karein."
            )
            return

        if not self.current_results:
            messagebox.showwarning(
                "No Results",
                "Koi matching result nahi."
            )
            return

        save = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[
                ("CSV", "*.csv")
            ],
            initialfile=(
                "SearchReport_"
                + re.sub(
                    r"[^A-Za-z0-9_-]+",
                    "_",
                    self.current_query,
                )
                + ".csv"
            ),
        )

        if not save:
            return

        try:
            with open(
                save,
                "w",
                encoding="utf-8-sig",
                newline="",
            ) as f:
                w = csv.writer(
                    f
                )

                w.writerow([
                    "Search Query",
                    self.current_query,
                ])

                w.writerow([
                    "Total Matches",
                    len(
                        self.current_results
                    ),
                ])

                w.writerow([])

                w.writerow([
                    "File",
                    "Type",
                    "Sheet",
                    "Row",
                    "Matched Cell(s)",
                    "Complete Row - ALL COLUMNS",
                ])

                for r in self.current_results:
                    w.writerow([
                        r["path"],
                        Path(
                            r["path"]
                        ).suffix.replace(
                            ".",
                            "",
                        ).upper(),
                        r["sheet"],
                        r["row"],
                        " | ".join(
                            f"[{c}]: {v}"
                            for c, v
                            in r["matched"]
                        ),
                        r["full"],
                    ])

            messagebox.showinfo(
                "Export Complete",
                (
                    f"ALL {len(self.current_results):,} "
                    f"matches exported.\n\n{save}"
                ),
            )

        except Exception as exc:
            messagebox.showerror(
                "Export Error",
                str(exc),
            )


def main():
    root = tk.Tk()
    app = App(
        root
    )

    def on_close():
        try:
            app.cancel_scan.set()
            app.index.close()
        except Exception:
            pass

        root.destroy()

    root.protocol(
        "WM_DELETE_WINDOW",
        on_close,
    )

    root.mainloop()


if __name__ == "__main__":
    main()
